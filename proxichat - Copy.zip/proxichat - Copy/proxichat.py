from flask import Flask, render_template, request, jsonify, redirect, url_for, session
import mysql.connector
import time
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

# MySQL database configuration
db_config = {
    'user': 'proxichat_user',
    'password': 'passpass',
    'host': 'localhost',
    'database': 'proxichat',
    'raise_on_warnings': True
}

def get_db_connection():
    return mysql.connector.connect(**db_config)

@app.route('/')
def home():
    # Redirect to login if the user is not logged in
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return redirect(url_for('profile'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username   = request.form['username']
        password   = request.form['password']
        age        = request.form['age']
        ethnicity  = request.form['ethnicity']
        works_at   = request.form['works_at']
        studies_at = request.form['studies_at']
        tags       = request.form['tags']
        password_hash = generate_password_hash(password)

        conn = get_db_connection()
        cursor = conn.cursor()

        # Check if username already exists
        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        existing_user = cursor.fetchone()

        if existing_user:
            cursor.close()
            conn.close()
            return "Username already exists!"

        # Insert new user
        cursor.execute("INSERT INTO users (user_id, username, password_hash) VALUES (UUID(), %s, %s)", (username, password_hash))
        
        # Get the user_id of the newly created user
        cursor.execute("SELECT user_id FROM users WHERE username = %s", (username,))
        user_id = cursor.fetchone()[0]

        # Insert profile information for the new user, including tags
        cursor.execute(
            "INSERT INTO profiles (user_id, tags, age, ethnicity, works_at, studies_at, last_active) "
            "VALUES (%s, %s, %s, %s, %s, %s, CURRENT_TIMESTAMP)",
            (user_id, tags, age, ethnicity, works_at, studies_at)
        )

        # Insert initial tracking status (disabled by default)
        cursor.execute("INSERT INTO tracking_status (user_id, tracking) VALUES (%s, FALSE)", (user_id,))

        conn.commit()
        cursor.close()
        conn.close()
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        user = cursor.fetchone()

        if user and check_password_hash(user['password_hash'], password):
            session['user_id'] = user['user_id']

            # Ensure that tracking is initially off after login
            cursor.execute("UPDATE tracking_status SET tracking = FALSE WHERE user_id = %s", (user['user_id'],))

            conn.commit()
            cursor.close()
            conn.close()

            return redirect(url_for('profile'))
        else:
            cursor.close()
            conn.close()
            return "Invalid credentials!"

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('login'))

@app.route('/profile', methods=['GET'])
def profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user_id = session['user_id']

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Retrieve user information including username
    cursor.execute("""
        SELECT u.username, p.tags, p.age, p.ethnicity, p.works_at, p.studies_at
        FROM users u
        JOIN profiles p ON u.user_id = p.user_id
        WHERE u.user_id = %s
    """, (user_id,))
    profile_data = cursor.fetchone()

    cursor.close()
    conn.close()

    if not profile_data:
        return jsonify({"error": "User not found"}), 404

    # Split tags into a list
    if profile_data['tags']:
        interests_list = [tag.strip() for tag in profile_data['tags'].split(',') if tag.strip()]
    else:
        interests_list = []

    return render_template('profile.html', profile=profile_data, interests_list=interests_list)

@app.route('/toggle_tracking', methods=['POST'])
def toggle_tracking():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user_id = session['user_id']

    conn = get_db_connection()
    cursor = conn.cursor()

    # Check if the user exists in the tracking_status table
    cursor.execute("SELECT tracking FROM tracking_status WHERE user_id = %s", (user_id,))
    result = cursor.fetchone()

    if not result:
        cursor.execute("INSERT INTO tracking_status (user_id, tracking) VALUES (%s, TRUE)", (user_id,))
        new_tracking_status = True
    else:
        # Toggle the tracking status
        new_tracking_status = not result[0]
        cursor.execute("UPDATE tracking_status SET tracking = %s WHERE user_id = %s", (new_tracking_status, user_id))

    # Update the user's location data if toggling to "off"
    if not new_tracking_status:
        cursor.execute("UPDATE profiles SET latitude = NULL, longitude = NULL WHERE user_id = %s", (user_id,))

    conn.commit()
    cursor.close()
    conn.close()

    return jsonify({"user_id": user_id, "tracking": new_tracking_status}), 200

@app.route('/map', methods=['GET'])
def map_page():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    return render_template('map.html')

@app.route('/get_all_users', methods=['GET'])
def get_all_users():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("""
        SELECT u.user_id, u.username, p.latitude, p.longitude, t.tracking
        FROM users u
        LEFT JOIN profiles p ON u.user_id = p.user_id
        LEFT JOIN tracking_status t ON u.user_id = t.user_id
    """)
    users = cursor.fetchall()

    cursor.close()
    conn.close()

    return jsonify({"users": users}), 200

@app.route('/find', methods=['GET'])
def find():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    return render_template('find.html')

@app.route('/find_users', methods=['GET'])
def find_users():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user_id = session['user_id']

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Retrieve the current user's tags
    cursor.execute("SELECT tags FROM profiles WHERE user_id = %s", (user_id,))
    current_user_tags_row = cursor.fetchone()
    if current_user_tags_row and current_user_tags_row['tags']:
        current_user_tags = set(
            tag.strip().lower() for tag in current_user_tags_row['tags'].split(',') if tag.strip()
        )
    else:
        current_user_tags = set()
    print("Current User Tags:", current_user_tags)  # Debugging

    # Retrieve all other users with their tags and location
    cursor.execute("""
        SELECT u.user_id, u.username, p.latitude, p.longitude, p.tags
        FROM users u
        JOIN profiles p ON u.user_id = p.user_id
        WHERE p.latitude IS NOT NULL AND p.longitude IS NOT NULL AND u.user_id != %s
    """, (user_id,))
    all_users = cursor.fetchall()

    similar_users = []

    for user in all_users:
        if user['tags']:
            user_tags = set(
                tag.strip().lower() for tag in user['tags'].split(',') if tag.strip()
            )
        else:
            user_tags = set()

        # Calculate the number of common interests
        common_interests = len(current_user_tags & user_tags)
        print(f"User: {user['username']}, User Tags: {user_tags}, Common Interests: {common_interests}")  # Debugging

        # Include all users but pass the common_interests count
        similar_users.append({
            'user_id': user['user_id'],
            'username': user['username'],
            'latitude': float(user['latitude']),
            'longitude': float(user['longitude']),
            'common_interests': common_interests
        })

    cursor.close()
    conn.close()

    return jsonify({'users': similar_users}), 200

@app.route('/update_location', methods=['POST'])
def update_location():
    user_id = session.get('user_id')
    latitude = request.json.get('latitude')
    longitude = request.json.get('longitude')

    if not user_id or latitude is None or longitude is None:
        return jsonify({"error": "User ID, latitude, and longitude are required"}), 400

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Check if tracking is enabled for the user
    cursor.execute("SELECT tracking FROM tracking_status WHERE user_id = %s", (user_id,))
    tracking_status = cursor.fetchone()

    if not tracking_status or not tracking_status['tracking']:
        cursor.close()
        conn.close()
        return jsonify({"error": "Tracking is disabled for this user"}), 403

    # Update user's location if tracking is enabled
    try:
        cursor.execute(
            "UPDATE profiles SET latitude = %s, longitude = %s, last_active = %s WHERE user_id = %s",
            (latitude, longitude, time.strftime('%Y-%m-%d %H:%M:%S'), user_id)
        )
        conn.commit()
    except mysql.connector.Error as err:
        conn.rollback()
        return jsonify({"error": f"Failed to update location: {err}"}), 500
    finally:
        cursor.close()
        conn.close()

    return jsonify({"message": "Location updated"}), 200

if __name__ == '__main__':
    app.run(debug=True)
