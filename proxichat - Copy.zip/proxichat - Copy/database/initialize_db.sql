-- Create database
CREATE DATABASE IF NOT EXISTS proxichat;

USE proxichat;

-- Table to store user credentials
CREATE TABLE IF NOT EXISTS users (
    user_id VARCHAR(36) PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL
);

-- Table to store user profiles
CREATE TABLE IF NOT EXISTS profiles (
    user_id VARCHAR(36) PRIMARY KEY,
    username VARCHAR(50),
    tags VARCHAR(255),
    ethnicity VARCHAR(50),
    age INT,
    works_at VARCHAR(100),
    studies_at VARCHAR(100),
    last_active TIMESTAMP,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Table to store tracking status
CREATE TABLE IF NOT EXISTS tracking_status (
    user_id VARCHAR(36) PRIMARY KEY,
    tracking BOOLEAN,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Insert sample data for testing purposes
INSERT INTO users (user_id, username, password_hash)
VALUES
    (UUID(), 'user1', 'hashed_password_1'),
    (UUID(), 'user2', 'hashed_password_2');

-- Query to retrieve the UUIDs of users
SELECT user_id, username FROM users;

-- Insert profiles
INSERT INTO profiles (user_id, username, tags, ethnicity, age, works_at, studies_at, last_active, latitude, longitude)
VALUES
    ('uuid_1', 'user1', 'tech,gaming,hiking', 'Asian', 25, 'Tech Company', 'University A', CURRENT_TIMESTAMP, 37.7749, -122.4194),
    ('uuid_2', 'user2', 'music,art,cooking', 'Hispanic', 30, 'Music Studio', 'University B', CURRENT_TIMESTAMP, 34.0522, -118.2437);

-- Insert tracking status
INSERT INTO tracking_status (user_id, tracking)
VALUES
    ('uuid_1', TRUE),
    ('uuid_2', TRUE);
